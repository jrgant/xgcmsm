context("Network Initialization and Summary Statistics")
