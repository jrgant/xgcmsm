context("Assigning Epidemic Parameters, Initial Conditions and Model Controls")
