## ---- echo=FALSE--------------------------------------------------------------
vers <- packageVersion("EpiModel")
year <- format(Sys.time(), "%Y")

## ---- eval=FALSE--------------------------------------------------------------
#  help(package = "EpiModel")

